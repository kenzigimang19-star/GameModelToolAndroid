# Game Model Tool Android — MVP 0.2 (source project)

Universal, plugin-based Android model viewer foundation.

## Implemented in source
- Android Kotlin app with OBJ file picker and OpenGL ES preview
- Format-neutral `ModelData`
- `ModelFormatPlugin` interface and `FormatRegistry`
- First parser plugin for OBJ: vertices, polygon faces, fan triangulation, negative indices, useful warnings for UV/normals/materials

## Not yet implemented
- YFT/YDR/YDD/YTD readers
- DFF/TXD import/export
- GLB/GLTF/STL modules
- Texture rendering, UV mapping, orbit/zoom controls
- APK has not been compiled or tested in this environment

See `ARCHITECTURE.md` for design and roadmap.
